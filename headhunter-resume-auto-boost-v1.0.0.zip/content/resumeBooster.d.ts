export {};
//# sourceMappingURL=resumeBooster.d.ts.map